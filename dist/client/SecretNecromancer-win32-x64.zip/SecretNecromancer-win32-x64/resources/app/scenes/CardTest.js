//imports
const Phaser = require("phaser");
const CardSprite = require("../classes/CardSprite");
const Fireball = require("../../server/game/cards/Fireball");
const Lightning = require("../../server/game/cards/Lightning");
const Shield = require("../../server/game/cards/Shield");
const Grandmaster = require("../../server/game/roles/Grandmaster");
const Wizard = require("../../server/game/roles/Wizard");
const Necromancer = require("../../server/game/roles/Necromancer");


/** 
 * Temporary Phaser scene to help test the card and construction of the group of cards 
 * just waiting on access to phaser
 */

 class CardTest extends Phaser.Scene {

    constructor(){
        super("CardTest");
    }

    preload(){}

    init(){}

    create(){
        let serverCard01 = new Fireball;
        let serverCard02 = new Lightning;
        let serverCard03 = new Shield;
        let serverRole01 = new Grandmaster;
        let serverRole02 = new Wizard;
        let serverRole03 = new Necromancer;

        let clientCard01 = new CardSprite(200, 200, serverCard01, this);
        let clientCard02 = new CardSprite(600, 200, serverCard02, this);
        let clientCard03 = new CardSprite(1000, 200, serverCard03, this);
        let clientRole01 = new CardSprite(200, 600, serverRole01, this);
        let clientRole02 = new CardSprite(600, 600, serverRole02, this);
        let clientRole03 = new CardSprite(1000, 600, serverRole03, this);
    }
 }

 // exports the class so it may be imported/required elsewhere
module.exports = CardTest;